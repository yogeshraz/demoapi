//
//  HTTPMethod.swift
//  asyncAPI
//
//  Created by Yogesh Raj on 02/12/23.
//

enum RequestMethod: String {
    case delete = "DELETE"
    case get = "GET"
    case patch = "PATCH"
    case post = "POST"
    case put = "PUT"
}

