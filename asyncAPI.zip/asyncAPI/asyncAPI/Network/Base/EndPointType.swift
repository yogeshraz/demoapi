//
//  EndPointType.swift
//  asyncAPI
//
//  Created by Yogesh Raj on 02/12/23.
//

protocol EndPointType {
    var scheme: String { get }
    var host: String { get }
    var path: String { get }
    var method: RequestMethod { get }
    var header: [String: String]? { get }
    var body: [String: String]? { get }
}

extension EndPointType {
    var scheme: String {
        return "https"
    }

    var host: String {
        return "dummyjson.com"
    }
}
