//
//  EndPoints.swift
//  asyncAPI
//
//  Created by Yogesh Raj on 02/12/23.
//

enum EndPoints {
    case products
}

extension EndPoints: EndPointType {
    var path: String {
        switch self {
        case .products:
            return "/products"
        }
    }

    var method: RequestMethod {
        switch self {
        case .products:
            return .get
        }
    }

    var header: [String: String]? {
        // Access Token to use in Bearer header
        let accessToken = ""
        switch self {
        case .products:
            return [
                "Authorization": "Bearer \(accessToken)",
                "Content-Type": "application/json;charset=utf-8"
            ]
        }
    }
    
    var body: [String: String]? {
        switch self {
        case .products:
            return nil
        }
    }
}
