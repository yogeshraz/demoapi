//
//  ViewController.swift
//  asyncAPI
//
//  Created by Yogesh Raj on 01/12/23.
//

import UIKit

class ViewController: UIViewController {
    
    let viewmodel = HomeViewModel()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        viewmodel.fetchData { [weak self] result in
            guard let self = self else { return }
            switch result {
            case .success(let response):
                print(response)
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }

}

