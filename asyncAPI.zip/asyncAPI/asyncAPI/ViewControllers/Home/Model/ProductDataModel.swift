//
//  ProductDataModel.swift
//  asyncAPI
//
//  Created by Yogesh Raj on 02/12/23.
//


// MARK: - Product
struct Product: Codable {
    var products: [ProductElement]?
    var total, skip, limit: Int?
}

// MARK: - ProductElement
struct ProductElement: Codable {
    var id: Int?
    var title, description: String?
    var price: Int?
    var discountPercentage, rating: Double?
    var stock: Int?
    var brand, category: String?
    var thumbnail: String?
    var images: [String]?
}
