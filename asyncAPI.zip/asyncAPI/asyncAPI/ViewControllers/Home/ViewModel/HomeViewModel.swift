//
//  HomeViewModel.swift
//  asyncAPI
//
//  Created by Yogesh Raj on 02/12/23.
//

import UIKit

final class HomeViewModel {

    var apiWorker = HomeApiWorker()
    
    
    func fetchData(completion: @escaping (Result<Product, RequestError>) -> Void) {
        Task(priority: .background) {
            let result = await apiWorker.getProductList()
            completion(result)
        }
    }
}
