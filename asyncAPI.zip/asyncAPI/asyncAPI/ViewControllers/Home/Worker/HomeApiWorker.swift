//
//  HomeApiWorker.swift
//  asyncAPI
//
//  Created by Yogesh Raj on 02/12/23.
//

protocol HomeApiWorkerProtocol {
    func getProductList() async -> Result<Product, RequestError>

}

struct HomeApiWorker: NetworkManager, HomeApiWorkerProtocol {
    func getProductList() async -> Result<Product, RequestError> {
        return await sendRequest(endpoint: EndPoints.products, responseModel: Product.self)
    }
}
